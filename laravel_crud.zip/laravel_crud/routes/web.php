<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\admin\AdminController;
use App\Http\Controllers\admin\UserController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/admin',[AdminController::class,'index'])->name('admin.index');
Route::post('/admin/login',[AdminController::class,'login'])->name('admin.login');
Route::get('/admin/dashboard',[AdminController::class,'dashboard'])->name('admin.dashboard');
Route::get('/admin/logout',[AdminController::class,'logout'])->name('admin.logout');

Route::get('/admin/users',[UserController::class,'index'])->name('admin.users');
Route::get('/admin/create/user',[UserController::class,'create'])->name('user.create');
Route::post('/admin/store/user',[UserController::class,'store'])->name('user.store');
Route::get('/admin/user/edit/{id}',[UserController::class,'edit'])->name('user.edit');
Route::put('/admin/user/update/{id}',[UserController::class,'update'])->name('user.update');



