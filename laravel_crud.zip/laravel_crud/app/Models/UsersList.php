<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Kyslik\ColumnSortable\Sortable;


class UsersList extends Model
{
    use HasFactory;
    use Sortable;
    protected $table = 'users_lists';
    protected $fillable = ['id','first_name','last_name','email','mobile','password','status','profile'];
    public $sortable = ['id','first_name','last_name','email','mobile','password','status','profile'];

}
