<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Admin;

class AdminController extends Controller
{
    public function index(Request $request){
        // dd($request->session()->get('admin_id'));
    	return view('admin.index');
    }

    public function login(Request $request){
    	$validated = $request->validate([
    		'email'=>'required',
    		'password'=>'required'
    	]);

    	$admin = Admin::where('email',$validated['email'])->where('password',$validated['password'])->get()->count();
        $admin_list = Admin::where('email',$validated['email'])->where('password',$validated['password'])->first();    	
        
    	if($admin>0){
            $request->session()->put('admin_id',$admin_list->id);
    		return redirect()->route('admin.dashboard');
    	}
    	else
    	{
    		return redirect()->route('admin.index')->with('message','Invalid Details');
    	}
    } 

    public function dashboard(Request $request){
        // dd($request->session()->get('admin_id'));
        if($request->session()->get('admin_id'))
        {
    	    return view('admin.dashboard');
        }
        else{
            return redirect()->route('admin.index');
        }
    } 

    public function logout(Request $request){
        $request->session()->forget('admin_id');
    	return redirect()->route('admin.index');
    } 
}
