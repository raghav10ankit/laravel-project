<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\UsersList;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        if($request->has('search'))
        {
            $search = $request['search'];
            $users = UsersList::where('first_name','LIKE',"%$search%")->orWhere('last_name','LIKE',"%$search%")->orWhere('email','LIKE',"%$search%")->sortable()->get();
        }
        else
        {
            $users = UsersList::sortable()->paginate(2);
        }

        if($request->session()->get('admin_id'))
        {
        return view('admin.users.users',['users'=>$users]);
        }
        else
        {
            return redirect()->route('admin.index');
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.users.add_user');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'first_name'=>'required',
            'last_name'=>'required',
            'email'=>'required',
            'mobile'=>'required',
            'password' => 'required',
            'status'=>'required',
            'profile'=>'required'
        ]);

        if($request->hasFile('profile')){
            $file = $request->file('profile');
            $extention = $file->getClientOriginalextension();
            $file_name = time().".".$extention;
            $file->move('public/img/user_profiles',$file_name);
        }
        
        $data = [
            'first_name'=>$validated['first_name'],
            'last_name'=>$validated['last_name'],
            'email'=>$validated['email'],
            'mobile'=>$validated['mobile'],
            'password'=>Hash::make($validated['password']),
            'status'=>$validated['status'],
            'profile'=>$file_name

        ];

        UsersList::create($data);
        return redirect()->route('admin.users')->with('message','User added successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $user = UsersList::findOrFail($id);
        $data = compact('user');

        return view('admin.users.edit_user',$data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validated = $request->validate([
            'first_name'=>'required',
            'last_name'=>'required',
            'email'=>'required',
            'mobile'=>'required',
            'status'=>'required'
        ]);

        $data = [
            'first_name'=>$validated['first_name'],
            'last_name'=>$validated['last_name'],
            'email'=>$validated['email'],
            'mobile'=>$validated['mobile'],
            'status'=>$validated['status']
        ];

        UsersList::where('id',$id)->update($data);
        return redirect()->route('admin.users')->with('message','User updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
