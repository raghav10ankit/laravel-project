
<?php $__env->startSection('title','Dashboard'); ?>
<?php $__env->startSection('content'); ?>

<div class="wrapper">
	
	<?php echo $__env->make('layouts.admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<div class="main">
		
		<?php echo $__env->make('layouts.admin.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

		<main class="content">
			<div class="container-fluid p-0">

				<!-- <h1 class="h3 mb-3"><strong>Analytics</strong> Dashboard</h1> -->

				<div class="row">
					<div class="col-12 col-lg-12 col-xxl-12 d-flex">
						<div class="card flex-fill">
							<div class="card-header d-flex justify-content-between" style="background-color: #34495e;">

								<div class="table-title">
									<h5 class="card-title mb-0 text-white">Add User</h5>
								</div>
							</div>
							<!-- Add User Form -->
							<div class="container-fluid">
								<form action="<?php echo e(route('user.store')); ?>" method="POST" enctype="multipart/form-data">
									<?php echo csrf_field(); ?>
									<div class="row">
										<div class="col-md-12 py-3">
											<div class="">
                                    			<!-- <img src="<?php echo e(asset('/public/img/avatars/default.jpg')); ?>" alt="Charles Hall" class="img-fluid rounded-circle" width="132" height="132" /> -->
                                    			<label class="form-label fw-bold">Profile</label>
                                    			<input class="form-control form-control-lg" type="file" name="profile" />
                                    		</div>
                                    		<span class="text-danger">
													<?php $__errorArgs = ['profile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
													<?php echo e($message); ?>

													<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
												</span>
										</div>
									</div>

									<div class="row">
										<div class="col-md-6">
											<div class="mb-3">
												<label class="form-label fw-bold">First Name</label>
												<input class="form-control form-control-lg" type="text" name="first_name" placeholder="Enter first name" value="<?php echo e(old('first_name')); ?>" />
												<span class="text-danger">
													<?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
													<?php echo e($message); ?>

													<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
												</span>
											</div>
										</div>
										<div class="col-md-6">
											<div class="mb-3">
												<label class="form-label fw-bold">Last Name</label>
												<input class="form-control form-control-lg" type="text" name="last_name" placeholder="Enter last name" value="<?php echo e(old('last_name')); ?>" />
												<span class="text-danger">
													<?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
													<?php echo e($message); ?>

													<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
												</span>
											</div>
										</div>
									</div>

									<div class="row">
										<div class="col-md-6">
											<div class="mb-3">
												<label class="form-label fw-bold">Email</label>
												<input class="form-control form-control-lg" type="text" name="email" placeholder="Enter email" value="<?php echo e(old('email')); ?>" />
												<span class="text-danger">
													<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
													<?php echo e($message); ?>

													<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
												</span>
											</div>
										</div>
										<div class="col-md-6">
											<div class="mb-3">
												<label class="form-label fw-bold">Mobile</label>
												<input class="form-control form-control-lg" type="number" name="mobile" placeholder="Enter mobile" value="<?php echo e(old('mobile')); ?>" />
												<span class="text-danger">
													<?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
													<?php echo e($message); ?>

													<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
												</span>
											</div>
										</div>
									</div>

									<div class="row">
										<div class="col-md-6">
											<div class="mb-3">
												<label class="form-label fw-bold">Password</label>
												<input class="form-control form-control-lg" type="password" name="password" placeholder="Enter password" value="<?php echo e(old('password')); ?>" />
												<span class="text-danger">
													<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
													<?php echo e($message); ?>

													<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
												</span>
											</div>
										</div>
										<div class="col-md-6">
											<div class="mb-3">
												<label class="form-label fw-bold">Confirm Password</label>
												<input class="form-control form-control-lg" type="password" name="password" placeholder="Enter password again" value="<?php echo e(old('password_confirmation')); ?>" />
												<span class="text-danger">
													<?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
													<?php echo e($message); ?>

													<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
												</span>
											</div>
										</div>
									</div>
                                    
                                    <div class="row">
                                    	<div class="col-md-6">
                                    		<label class="form-label fw-bold">Status:</label>
                                    		<select class="form-select form-select-lg mb-3" name="status">
                                    			<option value="" selected>Select Status</option>
                                    			<option value="1">Active</option>
                                    			<option value="0">Inactive</option>
                                    		</select>
                                    		<span class="text-danger">
													<?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
													<?php echo e($message); ?>

													<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
												</span>

                                    		<div class="mb-3">
                                    			<input class="btn btn-primary" type="submit" name="password" value="Add" />
                                    			<a href="<?php echo e(route('admin.users')); ?>" class="btn btn-secondary">Back</a>
                                    		</div>
                                    	</div>
                                    </div>
                       
								</form>
							</div>
						</div>
					</div>
				</div>

			</div>
		</main>

		<?php echo $__env->make('layouts.admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_crud\resources\views/admin/users/add_user.blade.php ENDPATH**/ ?>