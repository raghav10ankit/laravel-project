
<?php $__env->startSection('title','Dashboard'); ?>
<?php $__env->startSection('content'); ?>


<div class="wrapper">
	
	<?php echo $__env->make('layouts.admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<div class="main">
		
		<?php echo $__env->make('layouts.admin.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

		<main class="content">
			<div class="container-fluid p-0">

				<!-- <h1 class="h3 mb-3"><strong>Analytics</strong> Dashboard</h1> -->
                <div class="row">
                	<div class="col-lg-12 col-12 col-xxl-12">
                		<?php if(session('message')): ?>
                		<div class="alert alert-success alert-dismissible fade show">
                			<button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                			<strong><?php echo e(session('message')); ?></strong>
                		</div>
                		<?php endif; ?>
                	</div>
                </div>
				<div class="row">
					<div class="col-12 col-lg-12 col-xxl-12 d-flex">

						<div class="card flex-fill">
							<div class="card-header d-flex justify-content-between" style="background-color: #34495e;">
                                
								<div class="table-title">
									<h5 class="card-title mt-2 text-white">Users</h5>
								</div>

								<div class="table-options d-flex">
									<form action="<?php echo e(route('admin.users')); ?>" class="d-flex mx-5">
										<input type="text" class="form-control" name="search" placeholder="Search" value="<?php echo e(old('search')); ?>">
										<button type="submit" class="btn btn-primary mx-2">Search</button>
										<a href="<?php echo e(route('admin.users')); ?>" class="btn btn-danger">Clear</a>
									</form>
									<a href="<?php echo e(route('user.create')); ?>" class="btn btn-success">Add User</a>
								</div>
							</div>
							<?php if($users->count()>0): ?>
							<table class="table table-hover my-0">
								<thead>
									<tr>
										<th>Id</th>
										<th>Profile</th>
										<th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('first_name'));?></th>
										<th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('last_name'));?></th>
										<th class="d-none d-xl-table-cell"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('email'));?></th>
										<th class="d-none d-xl-table-cell"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('mobile'));?></th>
										<th>Status</th>
										<!-- <th class="d-none d-md-table-cell">Created At</th>
										<th class="d-none d-md-table-cell">Updated At</th> -->
										<th>Action</th>
									</tr>
								</thead>
								<tbody>
									<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($user->id); ?></td>
										<td>
											<img src="<?php echo e(asset('/public/img/user_profiles/').'/'.$user->profile); ?>" class="avatar img-fluid rounded-circle" alt="Vanessa Tucker">
										</td>
										<td><?php echo e($user->first_name); ?></td>
										<td><?php echo e($user->last_name); ?></td>
										<td class="d-none d-xl-table-cell"><?php echo e($user->email); ?></td>
										<td class="d-none d-xl-table-cell"><?php echo e($user->mobile); ?></td>
										<td>
											<span class="badge bg-<?php if($user->status==1): ?><?php echo e('success'); ?><?php else: ?><?php echo e('danger'); ?><?php endif; ?>"><?php if($user->status==1): ?><?php echo e('Active'); ?> <?php else: ?> <?php echo e('Inactive'); ?> <?php endif; ?></span>
										</td>
										<!-- <td class="d-none d-md-table-cell"><?php echo e($user->created_at); ?></td>
										<td class="d-none d-md-table-cell"><?php echo e($user->updated_at); ?></td> -->
										<td>
											<a href="<?php echo e(route('user.edit',$user->id)); ?>" class="btn btn-primary">
												<i class="align-middle" data-feather="edit"></i>
											</a>
											<button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#myModal"><i class="align-middle" data-feather="trash-2"></i></button>
										</td>
									</tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</tbody>
							</table>
							<?php echo $users->appends(\Request::except('page'))->render(); ?>

							<?php else: ?>
							<p class="text-center pt-3 text-secondary">No users found</p>
							<?php endif; ?>
						</div>
					</div>
				</div>

			</div>
		</main>

		<!-- <div class="modal" id="myModal">
			<div class="modal-dialog">
				<div class="modal-content">

					<div class="modal-header">
						<h4 class="modal-title">Modal Heading</h4>
						<button type="button" class="btn-close" data-bs-dismiss="modal"></button>
					</div>

					<div class="modal-body">
						Modal body..
					</div>

					<div class="modal-footer">
						<button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
					</div>

				</div>
			</div>
		</div> -->


		<?php echo $__env->make('layouts.admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_crud\resources\views/admin/users/users.blade.php ENDPATH**/ ?>