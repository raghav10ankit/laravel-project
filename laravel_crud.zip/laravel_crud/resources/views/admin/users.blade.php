@extends('layouts.admin.master')
@section('title','Dashboard')
@section('content')

<div class="wrapper">
	
	@include('layouts.admin.sidebar')

	<div class="main">
		
		@include('layouts.admin.navbar')

		<main class="content">
			<div class="container-fluid p-0">

				<!-- <h1 class="h3 mb-3"><strong>Analytics</strong> Dashboard</h1> -->

				<div class="row">
					<div class="col-12 col-lg-12 col-xxl-12 d-flex">
						<div class="card flex-fill">
							<div class="card-header d-flex justify-content-between">

								<div class="table-title">
									<h5 class="card-title mb-0">Users</h5>
								</div>

								<div class="table-options d-flex">
									<form action="{{route('admin.users')}}" class="d-flex mx-5">
										<input type="text" class="form-control" name="search" placeholder="Search">
										<button type="submit" class="btn btn-primary mx-2">Search</button>
										<a href="{{route('admin.users')}}" class="btn btn-danger">Clear</a>
									</form>
									<a href="{{route('user.create')}}" class="btn btn-success">Add User</a>
								</div>
							</div>
							<table class="table table-hover my-0">
								<thead>
									<tr>
										<th>Id</th>
										<th>Profile</th>
										<th>@sortablelink('first_name')</th>
										<th>@sortablelink('last_name')</th>
										<th class="d-none d-xl-table-cell">@sortablelink('email')</th>
										<th class="d-none d-xl-table-cell">@sortablelink('mobile')</th>
										<th>Status</th>
										<!-- <th class="d-none d-md-table-cell">Created At</th>
										<th class="d-none d-md-table-cell">Updated At</th> -->
										<th>Action</th>
									</tr>
								</thead>
								<tbody>
									@foreach($users as $user)
									<tr>
										<td>{{$user->id}}</td>
										<td>
											<img src="{{asset('/public/img/avatars/').'/'.$user->profile}}" class="avatar img-fluid rounded-circle" alt="Vanessa Tucker">
										</td>
										<td>{{$user->first_name}}</td>
										<td>{{$user->last_name}}</td>
										<td class="d-none d-xl-table-cell">{{$user->email}}</td>
										<td class="d-none d-xl-table-cell">{{$user->mobile}}</td>
										<td>
											<span class="badge bg-@if($user->status==1){{ 'success'}}@else{{'danger'}}@endif">@if($user->status==1){{ 'Active' }} @else {{ 'Inactive' }} @endif</span>
										</td>
										<!-- <td class="d-none d-md-table-cell">{{$user->created_at}}</td>
										<td class="d-none d-md-table-cell">{{$user->updated_at}}</td> -->
										<td>
											<a href="" class="btn btn-primary">
												<i class="align-middle" data-feather="edit"></i>
											</a>
											<button class="btn btn-danger">
												<i class="align-middle" data-feather="trash-2"></i>
											</button>
										</td>
									</tr>
									@endforeach
								</tbody>
							</table>
						</div>
					</div>
				</div>

			</div>
		</main>

		@include('layouts.admin.footer')
	</div>
</div>

@endsection