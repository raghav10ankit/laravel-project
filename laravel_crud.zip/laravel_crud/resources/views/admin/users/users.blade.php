@extends('layouts.admin.master')
@section('title','Dashboard')
@section('content')


<div class="wrapper">
	
	@include('layouts.admin.sidebar')

	<div class="main">
		
		@include('layouts.admin.navbar')

		<main class="content">
			<div class="container-fluid p-0">

				<!-- <h1 class="h3 mb-3"><strong>Analytics</strong> Dashboard</h1> -->
                <div class="row">
                	<div class="col-lg-12 col-12 col-xxl-12">
                		@if(session('message'))
                		<div class="alert alert-success alert-dismissible fade show">
                			<button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                			<strong>{{session('message')}}</strong>
                		</div>
                		@endif
                	</div>
                </div>
				<div class="row">
					<div class="col-12 col-lg-12 col-xxl-12 d-flex">

						<div class="card flex-fill">
							<div class="card-header d-flex justify-content-between" style="background-color: #34495e;">
                                
								<div class="table-title">
									<h5 class="card-title mt-2 text-white">Users</h5>
								</div>

								<div class="table-options d-flex">
									<form action="{{route('admin.users')}}" class="d-flex mx-5">
										<input type="text" class="form-control" name="search" placeholder="Search" value="{{old('search')}}">
										<button type="submit" class="btn btn-primary mx-2">Search</button>
										<a href="{{route('admin.users')}}" class="btn btn-danger">Clear</a>
									</form>
									<a href="{{route('user.create')}}" class="btn btn-success">Add User</a>
								</div>
							</div>
							@if($users->count()>0)
							<table class="table table-hover my-0">
								<thead>
									<tr>
										<th>Id</th>
										<th>Profile</th>
										<th>@sortablelink('first_name')</th>
										<th>@sortablelink('last_name')</th>
										<th class="d-none d-xl-table-cell">@sortablelink('email')</th>
										<th class="d-none d-xl-table-cell">@sortablelink('mobile')</th>
										<th>Status</th>
										<!-- <th class="d-none d-md-table-cell">Created At</th>
										<th class="d-none d-md-table-cell">Updated At</th> -->
										<th>Action</th>
									</tr>
								</thead>
								<tbody>
									@foreach($users as $user)
									<tr>
										<td>{{$user->id}}</td>
										<td>
											<img src="{{asset('/public/img/user_profiles/').'/'.$user->profile}}" class="avatar img-fluid rounded-circle" alt="Vanessa Tucker">
										</td>
										<td>{{$user->first_name}}</td>
										<td>{{$user->last_name}}</td>
										<td class="d-none d-xl-table-cell">{{$user->email}}</td>
										<td class="d-none d-xl-table-cell">{{$user->mobile}}</td>
										<td>
											<span class="badge bg-@if($user->status==1){{ 'success'}}@else{{'danger'}}@endif">@if($user->status==1){{ 'Active' }} @else {{ 'Inactive' }} @endif</span>
										</td>
										<!-- <td class="d-none d-md-table-cell">{{$user->created_at}}</td>
										<td class="d-none d-md-table-cell">{{$user->updated_at}}</td> -->
										<td>
											<a href="{{route('user.edit',$user->id)}}" class="btn btn-primary">
												<i class="align-middle" data-feather="edit"></i>
											</a>
											<button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#myModal"><i class="align-middle" data-feather="trash-2"></i></button>
										</td>
									</tr>
									@endforeach
								</tbody>
							</table>
							{!! $users->appends(\Request::except('page'))->render() !!}
							@else
							<p class="text-center pt-3 text-secondary">No users found</p>
							@endif
						</div>
					</div>
				</div>

			</div>
		</main>

		<!-- <div class="modal" id="myModal">
			<div class="modal-dialog">
				<div class="modal-content">

					<div class="modal-header">
						<h4 class="modal-title">Modal Heading</h4>
						<button type="button" class="btn-close" data-bs-dismiss="modal"></button>
					</div>

					<div class="modal-body">
						Modal body..
					</div>

					<div class="modal-footer">
						<button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
					</div>

				</div>
			</div>
		</div> -->


		@include('layouts.admin.footer')
	</div>
</div>



@endsection