@extends('layouts.admin.master')
@section('title','Dashboard')
@section('content')

<div class="wrapper">
	
	@include('layouts.admin.sidebar')

	<div class="main">
		
		@include('layouts.admin.navbar')

		<main class="content">
			<div class="container-fluid p-0">

				<!-- <h1 class="h3 mb-3"><strong>Analytics</strong> Dashboard</h1> -->

				<div class="row">
					<div class="col-12 col-lg-12 col-xxl-12 d-flex">
						<div class="card flex-fill">
							<div class="card-header d-flex justify-content-between" style="background-color: #34495e;">

								<div class="table-title">
									<h5 class="card-title mb-0 text-white">Add User</h5>
								</div>
							</div>
							<!-- Add User Form -->
							<div class="container-fluid">
								<form action="{{route('user.store')}}" method="POST" enctype="multipart/form-data">
									@csrf
									<div class="row">
										<div class="col-md-12 py-3">
											<div class="">
                                    			<!-- <img src="{{asset('/public/img/avatars/default.jpg')}}" alt="Charles Hall" class="img-fluid rounded-circle" width="132" height="132" /> -->
                                    			<label class="form-label fw-bold">Profile</label>
                                    			<input class="form-control form-control-lg" type="file" name="profile" />
                                    		</div>
                                    		<span class="text-danger">
													@error('profile')
													{{ $message }}
													@enderror
												</span>
										</div>
									</div>

									<div class="row">
										<div class="col-md-6">
											<div class="mb-3">
												<label class="form-label fw-bold">First Name</label>
												<input class="form-control form-control-lg" type="text" name="first_name" placeholder="Enter first name" value="{{old('first_name')}}" />
												<span class="text-danger">
													@error('first_name')
													{{ $message }}
													@enderror
												</span>
											</div>
										</div>
										<div class="col-md-6">
											<div class="mb-3">
												<label class="form-label fw-bold">Last Name</label>
												<input class="form-control form-control-lg" type="text" name="last_name" placeholder="Enter last name" value="{{old('last_name')}}" />
												<span class="text-danger">
													@error('last_name')
													{{ $message }}
													@enderror
												</span>
											</div>
										</div>
									</div>

									<div class="row">
										<div class="col-md-6">
											<div class="mb-3">
												<label class="form-label fw-bold">Email</label>
												<input class="form-control form-control-lg" type="text" name="email" placeholder="Enter email" value="{{old('email')}}" />
												<span class="text-danger">
													@error('email')
													{{ $message }}
													@enderror
												</span>
											</div>
										</div>
										<div class="col-md-6">
											<div class="mb-3">
												<label class="form-label fw-bold">Mobile</label>
												<input class="form-control form-control-lg" type="number" name="mobile" placeholder="Enter mobile" value="{{old('mobile')}}" />
												<span class="text-danger">
													@error('mobile')
													{{ $message }}
													@enderror
												</span>
											</div>
										</div>
									</div>

									<div class="row">
										<div class="col-md-6">
											<div class="mb-3">
												<label class="form-label fw-bold">Password</label>
												<input class="form-control form-control-lg" type="password" name="password" placeholder="Enter password" value="{{old('password')}}" />
												<span class="text-danger">
													@error('password')
													{{ $message }}
													@enderror
												</span>
											</div>
										</div>
										<div class="col-md-6">
											<div class="mb-3">
												<label class="form-label fw-bold">Confirm Password</label>
												<input class="form-control form-control-lg" type="password" name="password" placeholder="Enter password again" value="{{old('password_confirmation')}}" />
												<span class="text-danger">
													@error('password_confirmation')
													{{ $message }}
													@enderror
												</span>
											</div>
										</div>
									</div>
                                    
                                    <div class="row">
                                    	<div class="col-md-6">
                                    		<label class="form-label fw-bold">Status:</label>
                                    		<select class="form-select form-select-lg mb-3" name="status">
                                    			<option value="" selected>Select Status</option>
                                    			<option value="1">Active</option>
                                    			<option value="0">Inactive</option>
                                    		</select>
                                    		<span class="text-danger">
													@error('status')
													{{ $message }}
													@enderror
												</span>

                                    		<div class="mb-3">
                                    			<input class="btn btn-primary" type="submit" name="password" value="Add" />
                                    			<a href="{{route('admin.users')}}" class="btn btn-secondary">Back</a>
                                    		</div>
                                    	</div>
                                    </div>
                       
								</form>
							</div>
						</div>
					</div>
				</div>

			</div>
		</main>

		@include('layouts.admin.footer')
	</div>
</div>

@endsection